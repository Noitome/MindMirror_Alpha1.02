
# Copyright

**Work:** MindMirror / Mindmap-App  
**Author:** Daniel  
**First Public Disclosure:** 2025-08-18 (AEST, Australia/Melbourne)

Unless otherwise noted in file headers, the source code is:
> Copyright © 2025 Daniel  
> Licensed under the MIT License (see [LICENSE](./LICENSE)).

- Non-code assets (names, marks, brand, screenshots) are **not** granted under MIT unless explicitly stated.
- Third-party components remain under their respective licenses.
